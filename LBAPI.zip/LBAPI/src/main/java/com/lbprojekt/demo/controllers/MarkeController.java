package com.lbprojekt.demo.controllers;

import java.util.Locale.Category;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.lbprojekt.demo.model.Marke;
import com.lbprojekt.demo.model.MarkeRepository;

import jakarta.validation.Valid;

@RestController
@RequestMapping(path="/marke")
public class MarkeController {
    @Autowired
	private MarkeRepository markeRepository;

	@PostMapping(path = "") // Map ONLY POST Requests
	public ResponseEntity<@Valid Marke> addNewCategory(@Valid @RequestBody Marke marke) {

	
		markeRepository.save(marke);
		return ResponseEntity.ok(marke);
	}

	@GetMapping(path = "")
	public ResponseEntity<Iterable<Category>> getAllCategories() {
		Iterable<Category> categories = null;

		

		return ResponseEntity.ok(categories);
	}
}
