package com.lbprojekt.demo.controllers;

import java.util.Locale.Category;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.lbprojekt.demo.model.Celebrity;
import com.lbprojekt.demo.model.CelebrityRepository;


import jakarta.validation.Valid;

@RestController
@RequestMapping(path="/celebrity")
public class CelebrityController {
    @Autowired
    private CelebrityRepository celebrityRepository;

	@PostMapping(path = "") // Map ONLY POST Requests
	public ResponseEntity<Celebrity> addNewCelebrity(@Valid @RequestBody Celebrity celebrity) {
        System.out.println(celebrity.getName());
        celebrityRepository.save(celebrity);
		return ResponseEntity.ok(celebrity);
}

@GetMapping(path = "")
	public ResponseEntity<Iterable<Celebrity>> getAllCelebrities() {
        
		return ResponseEntity.ok(celebrityRepository.findAll());
}

    // PUT - Einen Celebrity aktualisieren
    @PutMapping(path = "/{id}")
    public ResponseEntity<String> updateCelebrity(
            @RequestParam int id,
            String name,
            Integer age,
            String description) {


        // Aktualisiere die Attribute
		Celebrity c = new Celebrity();
        c.setName(name);
        if (age != null) c.setAge(age);
        if (description != null) c.setDescription(description);

     
        return ResponseEntity.ok("Updated");
    }

    @DeleteMapping(path = "/{id}")
    public ResponseEntity<String> deleteCelebrity(@PathVariable int id) {
        // Überprüfen, ob der Celebrity existiert
        return celebrityRepository.findById(id).map(celebrity -> {
            // Löschen des Celebritys
            celebrityRepository.delete(celebrity);
            return ResponseEntity.ok("Celebrity mit ID " + id + " wurde gelöscht.");
        }).orElseGet(() -> {
            // Falls der Celebrity nicht gefunden wird, eine 404-Antwort zurückgeben
            return ResponseEntity.status(404).body("Celebrity mit ID " + id + " nicht gefunden.");
        });
    }
    }






