package com.lbprojekt.demo.model;

import org.springframework.data.repository.CrudRepository;

public interface CelebrityRepository extends CrudRepository<Celebrity, Integer> {

}
