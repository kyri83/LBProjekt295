package com.lbprojekt.demo.controllers;

import java.util.Locale.Category;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.lbprojekt.demo.model.Marke;
import com.lbprojekt.demo.model.MarkeRepository;
import com.lbprojekt.demo.model.Sneakers;
import com.lbprojekt.demo.model.SneakersRepository;

import io.swagger.v3.oas.annotations.parameters.RequestBody;
import jakarta.validation.Valid;

@RestController //Das macht die Klasse zu einem Kontroller
@RequestMapping(path="/sneakers")
public class SneakersController {
    
     @Autowired
	private SneakersRepository sneakersRepository;

	@PostMapping(path = "") // Map ONLY POST Requests
	public ResponseEntity<@Valid Sneakers> addNewSneakers(@Valid @RequestBody Sneakers sneakers) {

		sneakersRepository.save(sneakers);
		return ResponseEntity.ok(sneakers);
	}

	@GetMapping(path = "")
	public ResponseEntity<Iterable<Category>> getAllCategories() {
		Iterable<Category> categories = null;

	

		return ResponseEntity.ok(categories);
	}
}
