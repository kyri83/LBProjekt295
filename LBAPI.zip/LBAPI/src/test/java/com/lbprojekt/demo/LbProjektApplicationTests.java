package com.lbprojekt.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LbProjektApplicationTests {

	@Test
	void contextLoads() {
	}

}
